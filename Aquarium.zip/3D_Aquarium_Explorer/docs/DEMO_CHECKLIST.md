# Demonstration — 3D Aquarium Explorer

1. Launch with `START_WINDOWS.bat`; show the 3D aquarium and the 24-fish counter.
2. Orbit camera, zoom toward the reef, show animated plants and jellyfish.
3. Press `Tab` to open the Reef Lab settings panel.
4. Press `+` twice to raise the fish population to 32; reduce it with `-`.
5. Toggle `M` to compare school movement with independent swimming.
6. Press `F` to generate falling food and show fish seeking pellets.
7. Press `2`, `1`, then `T` for night, day and automatic light cycle.
8. Toggle `C`, `L`, and `U` to show sand caustics, light beams and waves.
9. Use `[`, `]` to change simulation speed; Space to pause; `P` for a clean full-screen scene.
10. Show `src/main.cpp` (fish update and input), `shaders/scene.vert` (wave motion) and `shaders/scene.frag` (lighting).
11. Record a 2–4 minute explanation in English; upload to YouTube with Public visibility and confirm the URL opens without login.
12. Put the public YouTube URL into the report PDF, upload the source to GitHub and submit three files separately.

The code uses neighbor-based separation, same-group alignment and cohesion, orbital roaming, boundary steering, and food seeking. These are simplified steering rules, not a trained artificial-intelligence model.
