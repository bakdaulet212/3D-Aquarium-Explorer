# Implementation notes

## Fish steering

Each fish has its own position, velocity, group, phase and speed. At each update, the program builds a desired direction from a wandering target and the combined steering terms:

- Separation: turn away from nearby fish, weighted by inverse squared distance.
- Alignment: steer toward the average velocities of nearby fish in the same group.
- Cohesion: steer toward the center of nearby fish in the same group.
- Boundaries: steer inward near the aquarium perimeter and top/bottom limits.
- Feeding: temporarily prioritize the nearest available pellet; mark it consumed when close enough.

A synchronous velocity update avoids applying neighbors' new velocities before later fish are processed. The simulation is capped at 64 fish. The naive neighborhood search is quadratic in fish count, which is acceptable at this size but not optimized for large schools.

## Graphics pipeline

Procedural sphere/cylinder/fin/leaf/floor/beam/water meshes produce indexed OpenGL vertex buffers. Model, view and perspective projection matrices are passed to a GLSL 330 vertex shader. A GLSL fragment shader calculates directional lighting, highlights, depth fog, animated caustics, tinted surface waves and translucent light shafts. A separate pixel-font HUD is rendered in screen space.

## Limitations

Wave motion is procedural vertex displacement rather than Navier–Stokes fluid simulation. Lighting shafts are translucent geometric beams, not physically accurate volumetric scattering. The program does not implement shadow maps or fish-to-rock collision physics. The cap of 64 fish and the speed bounds protect interactive demonstrations on modest graphics hardware.
