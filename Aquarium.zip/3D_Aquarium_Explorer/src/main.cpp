#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cctype>
#include <stdexcept>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

constexpr float PI=3.14159265358979323846f;

struct Vertex { glm::vec3 pos; glm::vec3 normal; };

struct Mesh {
    std::vector<Vertex> vertices;
    std::vector<unsigned int> indices;
    GLuint vao=0, vbo=0, ebo=0;
    void upload() {
        glGenVertexArrays(1,&vao);
        glGenBuffers(1,&vbo);
        glGenBuffers(1,&ebo);
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER,vbo);
        glBufferData(GL_ARRAY_BUFFER,vertices.size()*sizeof(Vertex),vertices.data(),GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,indices.size()*sizeof(unsigned int),indices.data(),GL_STATIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(0));
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(sizeof(glm::vec3)));
        glBindVertexArray(0);
    }
    void draw() const {
        glBindVertexArray(vao);
        glDrawElements(GL_TRIANGLES,static_cast<GLsizei>(indices.size()),GL_UNSIGNED_INT,nullptr);
    }
    void destroy() {
        if(ebo) glDeleteBuffers(1,&ebo);
        if(vbo) glDeleteBuffers(1,&vbo);
        if(vao) glDeleteVertexArrays(1,&vao);
        vao=vbo=ebo=0;
    }
};

void triangle(Mesh& m,unsigned int a,unsigned int b,unsigned int c) {
    m.indices.insert(m.indices.end(),{a,b,c});
}

Mesh sphere(int longitude,int latitude) {
    Mesh m;
    for(int j=0;j<=latitude;++j) {
        float phi=-PI*0.5f+PI*j/latitude;
        for(int i=0;i<=longitude;++i) {
            float theta=2.0f*PI*i/longitude;
            glm::vec3 p(std::cos(phi)*std::cos(theta),std::sin(phi),std::cos(phi)*std::sin(theta));
            m.vertices.push_back({p,p});
        }
    }
    for(int j=0;j<latitude;++j) for(int i=0;i<longitude;++i) {
        unsigned int a=j*(longitude+1)+i;
        unsigned int b=a+longitude+1;
        triangle(m,a,b,a+1);
        triangle(m,b,b+1,a+1);
    }
    return m;
}

Mesh cylinder(int sides) {
    Mesh m;
    for(int i=0;i<=sides;++i) {
        float a=2*PI*i/sides;
        glm::vec3 n(std::cos(a),0,std::sin(a));
        m.vertices.push_back({glm::vec3(n.x,0,n.z),n});
        m.vertices.push_back({glm::vec3(n.x,1,n.z),n});
    }
    for(int i=0;i<sides;++i) {
        unsigned int a=i*2;
        triangle(m,a,a+1,a+2);
        triangle(m,a+1,a+3,a+2);
    }
    return m;
}

Mesh finMesh() {
    Mesh m;
    std::array<glm::vec3,9> points={
        glm::vec3(0,0,0),glm::vec3(-0.9f,0.77f,0),glm::vec3(-0.65f,0,0),
        glm::vec3(0,0,0),glm::vec3(-0.65f,0,0),glm::vec3(-0.9f,-0.77f,0),
        glm::vec3(0,0,0),glm::vec3(-0.65f,0,0),glm::vec3(-0.9f,0.77f,0)
    };
    for(const auto& p:points) m.vertices.push_back({p,glm::vec3(0,0,1)});
    for(unsigned int i=0;i<9;++i) m.indices.push_back(i);
    return m;
}

Mesh leafMesh() {
    Mesh m;
    constexpr int N=12;
    for(int j=0;j<=N;++j) {
        float t=static_cast<float>(j)/N;
        float width=0.25f*std::pow(std::max(0.0f,1.0f-t),0.8f)*std::sin((t*0.85f+0.1f)*PI);
        float x=std::sin(t*2.2f)*0.15f;
        float z=t*t*0.25f;
        m.vertices.push_back({glm::vec3(x-width,t*3.5f,z),glm::vec3(0.1f,0,1)});
        m.vertices.push_back({glm::vec3(x+width,t*3.5f,z),glm::vec3(0.1f,0,1)});
    }
    for(int i=0;i<N;++i) {
        unsigned int a=i*2;
        triangle(m,a,a+2,a+1);
        triangle(m,a+1,a+2,a+3);
    }
    return m;
}

Mesh waterSurface() {
    Mesh m;
    const int N=56;
    for(int z=0;z<=N;++z) for(int x=0;x<=N;++x) {
        float fx=(float(x)/N-0.5f)*35.0f;
        float fz=(float(z)/N-0.5f)*35.0f;
        m.vertices.push_back({glm::vec3(fx,8.35f,fz),glm::vec3(0,1,0)});
    }
    for(int z=0;z<N;++z) for(int x=0;x<N;++x) {
        unsigned a=z*(N+1)+x;
        triangle(m,a,a+N+1,a+1);
        triangle(m,a+1,a+N+1,a+N+2);
    }
    return m;
}

Mesh lightBeam() {
    Mesh m;
    m.vertices={
        {{-0.4f,8.4f,0}, {0,0,1}},
        {{0.4f,8.4f,0}, {0,0,1}},
        {{-2.4f,-2.1f,2.7f}, {0,0,1}},
        {{2.4f,-2.1f,2.7f}, {0,0,1}}
    };
    triangle(m,0,2,1);
    triangle(m,1,2,3);
    return m;
}

Mesh seabed() {
    Mesh m;
    const int N=50;
    for(int j=0;j<=N;++j) for(int i=0;i<=N;++i) {
        float x=(static_cast<float>(i)/N-0.5f)*35.0f;
        float z=(static_cast<float>(j)/N-0.5f)*35.0f;
        float y=-2.4f+0.13f*std::sin(x*0.8f)*std::cos(z*0.65f)+0.09f*std::sin(x*1.9f+z*0.8f);
        m.vertices.push_back({glm::vec3(x,y,z),glm::normalize(glm::vec3(-0.15f*std::cos(x*0.8f),1,-0.11f*std::sin(z*0.65f)))});
    }
    for(int j=0;j<N;++j) for(int i=0;i<N;++i) {
        unsigned int a=j*(N+1)+i;
        triangle(m,a,a+N+1,a+1);
        triangle(m,a+1,a+N+1,a+N+2);
    }
    return m;
}

GLuint makeShader(GLenum type,const std::string& src) {
    GLuint shader=glCreateShader(type);
    const char* str=src.c_str();
    glShaderSource(shader,1,&str,nullptr);
    glCompileShader(shader);
    GLint good=0;
    glGetShaderiv(shader,GL_COMPILE_STATUS,&good);
    if(!good) {
        char msg[4096];
        glGetShaderInfoLog(shader,sizeof(msg),nullptr,msg);
        throw std::runtime_error(std::string("Shader error: ")+msg);
    }
    return shader;
}

std::string loadFile(const std::string& filename) {
    std::ifstream in(filename);
    if(!in) throw std::runtime_error("Cannot read: "+filename);
    std::ostringstream s;
    s<<in.rdbuf();
    return s.str();
}

GLuint makeProgram(const std::string& vertex,const std::string& fragment) {
    GLuint v=makeShader(GL_VERTEX_SHADER,loadFile(vertex));
    GLuint f=makeShader(GL_FRAGMENT_SHADER,loadFile(fragment));
    GLuint program=glCreateProgram();
    glAttachShader(program,v);
    glAttachShader(program,f);
    glLinkProgram(program);
    GLint good=0;
    glGetProgramiv(program,GL_LINK_STATUS,&good);
    glDeleteShader(v);
    glDeleteShader(f);
    if(!good) {
        char msg[4096];
        glGetProgramInfoLog(program,sizeof(msg),nullptr,msg);
        throw std::runtime_error(std::string("Link error: ")+msg);
    }
    return program;
}

struct Object {
    int geometry=0;
    glm::mat4 model=glm::mat4(1);
    glm::vec3 color=glm::vec3(1);
    float glow=0;
    float plant=0;
    float floor=0;
};

struct Fish {
    glm::vec3 position{};
    glm::vec3 velocity{};
    int school=0;
    glm::vec3 color{};
    float angle=0;
    float radius=0;
    float height=0;
    float speed=0;
    float phase=0;
    float size=1;
    float heading=0;
};

struct Jellyfish {
    glm::vec3 origin{};
    glm::vec3 color{};
    float phase=0;
    float size=1;
};

struct Bubble {
    glm::vec3 origin{};
    float offset=0;
    float speed=0;
    float radius=0;
};

struct Food {
    glm::vec3 position{};
    float speed=0;
    bool alive=false;
};

struct Scene {
    std::vector<Object> objects;
    std::vector<Fish> fish;
    std::vector<Jellyfish> jellyfish;
    std::vector<Bubble> bubbles;
    std::vector<Food> food;
    float time=0;
    float foodTimer=0;
    bool bubblesEnabled=true;
    bool paused=false;
    float day=1;
    int feedCount=0;
    int foodEaten=0;
    bool schooling=true;
    bool caustics=true;
    bool rays=true;
    bool surface=true;
    bool jellyEnabled=true;
    bool autoCycle=false;
    float speedScale=1.0f;
    float lightPower=1.0f;
    std::mt19937 gen{217};
    float random(float lo,float hi) {return std::uniform_real_distribution<float>(lo,hi)(gen);}
    void place(int mesh,const glm::mat4& model,glm::vec3 color,float glow=0,float plant=0,float floor=0) {
        objects.push_back({mesh,model,color,glow,plant,floor});
    }
    glm::mat4 transform(glm::vec3 pos,glm::vec3 scale,float ry=0) {
        glm::mat4 m=glm::translate(glm::mat4(1),pos);
        m=glm::rotate(m,ry,glm::vec3(0,1,0));
        return glm::scale(m,scale);
    }
    void initialize() {
        objects.clear(); fish.clear(); jellyfish.clear(); bubbles.clear(); food.clear();
        gen.seed(217);
        place(3,glm::mat4(1),glm::vec3(0.68f,0.59f,0.40f),0,0,1);
        for(int k=0;k<25;++k) {
            float a=random(-PI,PI);
            float d=random(4.4f,14.0f);
            float x=std::sin(a)*d;
            float z=std::cos(a)*d;
            if(std::abs(x)<2.5f && z>2.0f && z<7.0f) continue;
            float s=random(0.45f,1.75f);
            place(0,transform({x,-2.31f,z},{s*1.2f,s*0.55f,s}),{random(0.26f,0.46f),random(0.41f,0.56f),random(0.43f,0.57f)});
        }
        for(int k=0;k<43;++k) {
            float a=random(0,2*PI),d=random(2.0f,14.5f);
            float x=std::sin(a)*d,z=std::cos(a)*d;
            float h=random(1.6f,3.9f);
            int count=static_cast<int>(random(3,7));
            glm::vec3 c=random(0,1)>0.47f?glm::vec3(0.11f,0.53f,0.32f):glm::vec3(0.16f,0.42f,0.39f);
            for(int j=0;j<count;++j) {
                float b=2*PI*j/count;
                glm::mat4 t=glm::translate(glm::mat4(1),glm::vec3(x,-2.33f,z));
                t=glm::rotate(t,b,glm::vec3(0,1,0));
                t=glm::rotate(t,0.24f*std::sin(b),glm::vec3(0,0,1));
                t=glm::scale(t,glm::vec3(random(0.65f,1.1f),h/3.5f,1));
                place(4,t,c,0.06f,1);
            }
        }
        for(int k=0;k<18;++k) {
            float a=random(0,2*PI),d=random(3.2f,12.5f);
            float x=std::sin(a)*d,z=std::cos(a)*d;
            glm::vec3 col=k%3==0?glm::vec3(1.0f,0.32f,0.38f):k%3==1?glm::vec3(0.97f,0.53f,0.24f):glm::vec3(0.66f,0.35f,0.77f);
            float scale=random(0.8f,1.45f);
            for(int j=0;j<5;++j) {
                float aa=2*PI*j/5+random(-0.24f,0.24f);
                float len=random(0.7f,1.6f)*scale;
                glm::vec3 start(x,-2.25f,z);
                glm::mat4 t=glm::translate(glm::mat4(1),start);
                t=glm::rotate(t,aa,glm::vec3(0,1,0));
                t=glm::rotate(t,random(-0.6f,0.6f),glm::vec3(1,0,0));
                t=glm::rotate(t,random(-0.7f,0.7f),glm::vec3(0,0,1));
                t=glm::scale(t,glm::vec3(0.12f*scale,len,0.12f*scale));
                place(1,t,col,0.1f);
                glm::vec3 tip=start+glm::vec3(std::sin(aa)*len*0.45f,len*0.82f,std::cos(aa)*len*0.45f);
                place(0,transform(tip,glm::vec3(0.19f*scale)),col,0.14f);
            }
        }
        for(int k=0;k<16;++k) {
            float a=random(0,2*PI),r=random(5.3f,12.8f),x=std::sin(a)*r,z=std::cos(a)*r;
            glm::vec3 col=k%2?glm::vec3(0.29f,0.79f,0.71f):glm::vec3(0.75f,0.41f,0.83f);
            for(int j=0;j<5;++j) {
                float theta=2*PI*j/5;
                place(0,transform(glm::vec3(x+0.34f*std::cos(theta),-2.02f+0.2f*std::sin(j),z+0.34f*std::sin(theta)),glm::vec3(0.24f,0.36f,0.24f)),col,0.08f);
            }
        }
        for(int j=0;j<2;++j) {
            float x=j==0?-4.9f:-1.7f;
            for(int h=0;h<5;++h)
                place(0,transform({x,-1.95f+h*0.63f,-5.5f},{0.57f,0.39f,0.58f}),{0.28f,0.44f,0.46f},0.025f);
        }
        place(0,transform({-3.3f,1.0f,-5.5f},{2.3f,0.39f,0.68f}),{0.32f,0.54f,0.53f},0.035f);
        place(0,transform({-3.3f,-1.82f,-5.5f},{0.7f,0.23f,0.8f}),{0.23f,0.74f,0.69f},0.36f);
        for(int i=0;i<8;++i) {
            Jellyfish j;
            j.origin={random(-10,10),random(2.1f,6.0f),random(-10,10)};
            j.phase=random(0,2*PI);
            j.size=random(0.55f,1.05f);
            j.color=i%3==0?glm::vec3(0.29f,0.88f,1.0f):(i%3==1?glm::vec3(0.79f,0.42f,0.96f):glm::vec3(0.38f,1.0f,0.75f));
            jellyfish.push_back(j);
        }
        setFishCount(24);
        for(int i=0;i<105;++i) {
            Bubble b;
            b.origin=glm::vec3(random(-11,11),-2.0f,random(-11,11));
            b.offset=random(0,12.0f);
            b.speed=random(0.6f,1.65f);
            b.radius=random(0.028f,0.13f);
            bubbles.push_back(b);
        }
        time=0;
        foodTimer=0;
        feedCount=0;
        foodEaten=0;
        speedScale=1.0f;
        autoCycle=false;
        day=1;
        bubblesEnabled=true;
        caustics=true;
        schooling=true;
        rays=true;
        surface=true;
        jellyEnabled=true;
        paused=false;
    }
    void setFishCount(int count) {
        count=glm::clamp(count,8,64);
        while(static_cast<int>(fish.size())>count) fish.pop_back();
        while(static_cast<int>(fish.size())<count) {
            int i=static_cast<int>(fish.size());
            Fish f;
            f.angle=random(0,2*PI);
            f.radius=random(3.0f,10.4f);
            f.height=random(-0.3f,5.6f);
            f.speed=random(0.17f,0.34f)*(i%2?1.0f:-1.0f);
            f.phase=random(0,2*PI);
            f.size=random(0.46f,1.12f);
            f.school=i%3;
            f.color=(i%5==0)?glm::vec3(1.0f,0.72f,0.22f):(i%5==1)?glm::vec3(0.98f,0.33f,0.34f):(i%5==2)?glm::vec3(0.18f,0.81f,0.88f):(i%5==3)?glm::vec3(0.72f,0.47f,0.94f):glm::vec3(1.0f,0.87f,0.46f);
            f.position={f.radius*std::sin(f.angle),f.height,f.radius*std::cos(f.angle)};
            f.velocity=glm::vec3(std::cos(f.angle),0,-std::sin(f.angle))*(f.speed>0?1.1f:-1.1f);
            f.heading=std::atan2(-f.velocity.z,f.velocity.x);
            fish.push_back(f);
        }
    }
    void feed() {
        food.clear();
        for(int i=0;i<38;++i) {
            Food p;
            p.position=glm::vec3(random(-2.2f,2.2f),random(7.7f,9.7f),random(-1.6f,1.6f));
            p.speed=random(0.58f,1.4f);
            p.alive=true;
            food.push_back(p);
        }
        foodTimer=8.0f;
        ++feedCount;
    }
    void update(float dt) {
        if(paused) return;
        dt=std::min(dt,0.05f)*speedScale;
        time+=dt;
        foodTimer=std::max(0.0f,foodTimer-dt);
        if(autoCycle) day=0.5f+0.5f*std::sin(time*0.13f+PI*0.5f);
        for(auto& pellet:food) {
            if(!pellet.alive) continue;
            pellet.position.y-=pellet.speed*dt;
            pellet.position.x+=0.12f*std::sin(time+pellet.position.z)*dt;
            if(pellet.position.y<-1.95f) pellet.alive=false;
        }
        std::vector<glm::vec3> nextVelocity(fish.size());
        for(size_t i=0;i<fish.size();++i) {
            Fish& f=fish[i];
            f.angle+=dt*f.speed;
            glm::vec3 target(std::sin(f.angle)*f.radius,f.height+0.37f*std::sin(time+f.phase),std::cos(f.angle)*f.radius);
            glm::vec3 steering=glm::normalize(target-f.position+glm::vec3(0.01f,0,0))*1.1f;
            glm::vec3 separation(0),alignment(0),cohesion(0);
            int neighbors=0;
            for(size_t j=0;j<fish.size();++j) {
                if(i==j) continue;
                glm::vec3 delta=f.position-fish[j].position;
                float d2=glm::dot(delta,delta);
                if(d2>0.0001f&&d2<5.8f) separation+=delta/(d2+0.15f);
                if(schooling && f.school==fish[j].school && d2<35.0f) {
                    alignment+=fish[j].velocity;
                    cohesion+=fish[j].position;
                    ++neighbors;
                }
            }
            if(glm::length(separation)>0.01f) steering+=glm::normalize(separation)*2.55f;
            if(schooling&&neighbors>0) {
                glm::vec3 center=cohesion/float(neighbors);
                glm::vec3 close=center-f.position;
                if(glm::length(close)>0.1f) steering+=glm::normalize(close)*0.57f;
                if(glm::length(alignment)>0.1f) steering+=glm::normalize(alignment)*0.72f;
            }
            float distance=glm::length(glm::vec2(f.position.x,f.position.z));
            if(distance>10.6f) steering+=glm::normalize(glm::vec3(-f.position.x,0,-f.position.z))*(distance-10.6f)*1.55f;
            if(f.position.y>5.7f) steering.y-=2.2f*(f.position.y-5.7f);
            if(f.position.y<-1.5f) steering.y+=2.2f*(-1.5f-f.position.y);
            if(foodTimer>0.0f) {
                float nearest=1000000.0f;
                glm::vec3 feedingTarget(0,1.5f,0);
                for(const auto& pellet:food) if(pellet.alive) {
                    float dist2=glm::dot(f.position-pellet.position,f.position-pellet.position);
                    if(dist2<nearest) {nearest=dist2;feedingTarget=pellet.position;}
                }
                glm::vec3 feedDir=feedingTarget-f.position;
                if(glm::length(feedDir)>0.1f) steering+=glm::normalize(feedDir)*3.3f;
                if(nearest<0.47f*0.47f) for(auto& pellet:food) if(pellet.alive && glm::length(pellet.position-f.position)<0.47f) {
                    pellet.alive=false;
                    ++foodEaten;
                    break;
                }
            }
            float len=glm::length(steering);
            if(len>0.001f) steering/=len;
            glm::vec3 desired=steering*(foodTimer>0?2.6f:1.75f);
            nextVelocity[i]=glm::mix(f.velocity,desired,glm::clamp(dt*1.65f,0.0f,1.0f));
        }
        for(size_t i=0;i<fish.size();++i) {
            fish[i].velocity=nextVelocity[i];
            fish[i].position+=fish[i].velocity*dt;
            glm::vec3& pos=fish[i].position;
            float d=glm::length(glm::vec2(pos.x,pos.z));
            if(d>13.2f) {pos.x*=13.2f/d;pos.z*=13.2f/d;fish[i].velocity.x*=-0.25f;fish[i].velocity.z*=-0.25f;}
            pos.y=glm::clamp(pos.y,-1.9f,7.0f);
            glm::vec3 v=fish[i].velocity;
            if(glm::length(glm::vec2(v.x,v.z))>0.001f) fish[i].heading=std::atan2(-v.z,v.x);
        }
    }
};

struct Camera {
    float yaw=0.46f;
    float pitch=0.23f;
    float radius=27.0f;
    glm::vec3 position() const {
        return glm::vec3(radius*std::sin(yaw)*std::cos(pitch),2.0f+radius*std::sin(pitch),radius*std::cos(yaw)*std::cos(pitch));
    }
    void clamp() {
        pitch=glm::clamp(pitch,-0.28f,1.1f);
        radius=glm::clamp(radius,12.0f,44.0f);
    }
};

struct HudVertex {float x,y,r,g,b,a;};

const std::unordered_map<char,std::array<const char*,7>> FONT={
{'A',{"01110","10001","10001","11111","10001","10001","10001"}},
{'B',{"11110","10001","10001","11110","10001","10001","11110"}},
{'C',{"01111","10000","10000","10000","10000","10000","01111"}},
{'D',{"11110","10001","10001","10001","10001","10001","11110"}},
{'E',{"11111","10000","10000","11110","10000","10000","11111"}},
{'F',{"11111","10000","10000","11110","10000","10000","10000"}},
{'G',{"01111","10000","10000","10111","10001","10001","01111"}},
{'H',{"10001","10001","10001","11111","10001","10001","10001"}},
{'I',{"11111","00100","00100","00100","00100","00100","11111"}},
{'J',{"00111","00010","00010","00010","10010","10010","01100"}},
{'K',{"10001","10010","10100","11000","10100","10010","10001"}},
{'L',{"10000","10000","10000","10000","10000","10000","11111"}},
{'M',{"10001","11011","10101","10101","10001","10001","10001"}},
{'N',{"10001","11001","10101","10011","10001","10001","10001"}},
{'O',{"01110","10001","10001","10001","10001","10001","01110"}},
{'P',{"11110","10001","10001","11110","10000","10000","10000"}},
{'Q',{"01110","10001","10001","10001","10101","10010","01101"}},
{'R',{"11110","10001","10001","11110","10100","10010","10001"}},
{'S',{"01111","10000","10000","01110","00001","00001","11110"}},
{'T',{"11111","00100","00100","00100","00100","00100","00100"}},
{'U',{"10001","10001","10001","10001","10001","10001","01110"}},
{'V',{"10001","10001","10001","10001","10001","01010","00100"}},
{'W',{"10001","10001","10001","10101","10101","10101","01010"}},
{'X',{"10001","10001","01010","00100","01010","10001","10001"}},
{'Y',{"10001","10001","01010","00100","00100","00100","00100"}},
{'Z',{"11111","00001","00010","00100","01000","10000","11111"}},
{'0',{"01110","10001","10011","10101","11001","10001","01110"}},
{'1',{"00100","01100","00100","00100","00100","00100","01110"}},
{'2',{"01110","10001","00001","00010","00100","01000","11111"}},
{'3',{"11110","00001","00001","01110","00001","00001","11110"}},
{'4',{"00010","00110","01010","10010","11111","00010","00010"}},
{'5',{"11111","10000","10000","11110","00001","00001","11110"}},
{'6',{"01111","10000","10000","11110","10001","10001","01110"}},
{'7',{"11111","00001","00010","00100","01000","01000","01000"}},
{'8',{"01110","10001","10001","01110","10001","10001","01110"}},
{'9',{"01110","10001","10001","01111","00001","00001","11110"}},
{'+',{"00000","00100","00100","11111","00100","00100","00000"}},
{'[',{"01110","01000","01000","01000","01000","01000","01110"}},
{']',{"01110","00010","00010","00010","00010","00010","01110"}},
{'%',{"11001","11010","00100","00100","01011","10011","00000"}},
{' ',{"00000","00000","00000","00000","00000","00000","00000"}},
{':',{"00000","00100","00100","00000","00100","00100","00000"}},
{'/',{"00001","00001","00010","00100","01000","10000","10000"}},
{'-',{"00000","00000","00000","11111","00000","00000","00000"}},
{'.',{"00000","00000","00000","00000","00000","01100","01100"}},
{'|',{"00100","00100","00100","00100","00100","00100","00100"}}
};

struct Hud {
    GLuint vao=0,vbo=0,program=0;
    std::vector<HudVertex> vertices;
    void init() {
        program=makeProgram("shaders/hud.vert","shaders/hud.frag");
        glGenVertexArrays(1,&vao);
        glGenBuffers(1,&vbo);
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER,vbo);
        glBufferData(GL_ARRAY_BUFFER,600000,nullptr,GL_DYNAMIC_DRAW);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(HudVertex),reinterpret_cast<void*>(0));
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1,4,GL_FLOAT,GL_FALSE,sizeof(HudVertex),reinterpret_cast<void*>(sizeof(float)*2));
    }
    void rect(float x,float y,float w,float h,glm::vec4 c) {
        HudVertex a{x,y,c.r,c.g,c.b,c.a},b{x+w,y,c.r,c.g,c.b,c.a};
        HudVertex d{x,y+h,c.r,c.g,c.b,c.a},e{x+w,y+h,c.r,c.g,c.b,c.a};
        vertices.insert(vertices.end(),{a,b,d,b,e,d});
    }
    void text(float x,float y,const std::string& s,float size,glm::vec4 color) {
        for(char raw:s) {
            char ch=static_cast<char>(std::toupper(static_cast<unsigned char>(raw)));
            auto found=FONT.find(ch);
            if(found!=FONT.end()) {
                const auto& rows=found->second;
                for(int j=0;j<7;++j) for(int i=0;i<5;++i)
                    if(rows[j][i]=='1') rect(x+i*size,y+j*size,size*0.92f,size*0.92f,color);
            }
            x+=size*6;
        }
    }
    void render(int width,int height) {
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glUseProgram(program);
        glUniform2f(glGetUniformLocation(program,"uResolution"),static_cast<float>(width),static_cast<float>(height));
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER,vbo);
        glBufferData(GL_ARRAY_BUFFER,vertices.size()*sizeof(HudVertex),vertices.data(),GL_DYNAMIC_DRAW);
        glDrawArrays(GL_TRIANGLES,0,static_cast<GLsizei>(vertices.size()));
        glEnable(GL_DEPTH_TEST);
        vertices.clear();
    }
    void destroy() {
        if(vbo) glDeleteBuffers(1,&vbo);
        if(vao) glDeleteVertexArrays(1,&vao);
        if(program) glDeleteProgram(program);
    }
};

struct App {
    GLFWwindow* window=nullptr;
    Camera camera;
    Scene scene;
    std::array<Mesh,7> meshes;
    GLuint program=0;
    Hud hud;
    int width=1280,height=720;
    bool help=true;
    bool photoMode=false;
    bool settingsPanel=false;
    bool dragging=false;
    double mouseX=0,mouseY=0;
    double lastTime=0,lastFps=0;
    float fps=0;
    int frames=0;
    void draw(int geo,const glm::mat4& model,glm::vec3 color,float glow=0,float alpha=1,float plant=0,float floor=0) {
        glUniformMatrix4fv(glGetUniformLocation(program,"uModel"),1,GL_FALSE,glm::value_ptr(model));
        glUniform3fv(glGetUniformLocation(program,"uColor"),1,glm::value_ptr(color));
        glUniform1f(glGetUniformLocation(program,"uGlow"),glow);
        glUniform1f(glGetUniformLocation(program,"uAlpha"),alpha);
        glUniform1f(glGetUniformLocation(program,"uPlant"),plant);
        glUniform1f(glGetUniformLocation(program,"uFloor"),floor);
        glUniform1f(glGetUniformLocation(program,"uSurface"),geo==5?1.0f:0.0f);
        glUniform1f(glGetUniformLocation(program,"uBeam"),geo==6?1.0f:0.0f);
        meshes[geo].draw();
    }
    glm::mat4 model(glm::vec3 pos,glm::vec3 scale,float rotationY=0) {
        return scene.transform(pos,scale,rotationY);
    }
    void initialize() {
        meshes[0]=sphere(18,12);
        meshes[1]=cylinder(9);
        meshes[2]=finMesh();
        meshes[3]=seabed();
        meshes[4]=leafMesh();
        meshes[5]=waterSurface();
        meshes[6]=lightBeam();
        for(auto& mesh:meshes) mesh.upload();
        program=makeProgram("shaders/scene.vert","shaders/scene.frag");
        hud.init();
        scene.initialize();
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
    }
    void controls(float dt) {
        if(glfwGetKey(window,GLFW_KEY_A)==GLFW_PRESS || glfwGetKey(window,GLFW_KEY_LEFT)==GLFW_PRESS) camera.yaw-=dt*0.8f;
        if(glfwGetKey(window,GLFW_KEY_D)==GLFW_PRESS || glfwGetKey(window,GLFW_KEY_RIGHT)==GLFW_PRESS) camera.yaw+=dt*0.8f;
        if(glfwGetKey(window,GLFW_KEY_UP)==GLFW_PRESS) camera.pitch+=dt*0.5f;
        if(glfwGetKey(window,GLFW_KEY_DOWN)==GLFW_PRESS) camera.pitch-=dt*0.5f;
        if(glfwGetKey(window,GLFW_KEY_W)==GLFW_PRESS) camera.radius-=dt*9;
        if(glfwGetKey(window,GLFW_KEY_S)==GLFW_PRESS) camera.radius+=dt*9;
        camera.clamp();
    }
    void render() {
        glfwGetFramebufferSize(window,&width,&height);
        if(width<=0||height<=0) return;
        glViewport(0,0,width,height);
        float day=scene.day;
        glClearColor(0.005f+day*0.008f,0.025f+day*0.061f,0.061f+day*0.11f,1);
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
        glm::vec3 eye=camera.position();
        glm::mat4 view=glm::lookAt(eye,glm::vec3(0,1.3f,0),glm::vec3(0,1,0));
        glm::mat4 projection=glm::perspective(glm::radians(52.0f),static_cast<float>(width)/height,0.08f,120.0f);
        glUseProgram(program);
        glUniformMatrix4fv(glGetUniformLocation(program,"uView"),1,GL_FALSE,glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(program,"uProjection"),1,GL_FALSE,glm::value_ptr(projection));
        glUniform3fv(glGetUniformLocation(program,"uCamera"),1,glm::value_ptr(eye));
        glUniform1f(glGetUniformLocation(program,"uTime"),scene.time);
        glUniform1f(glGetUniformLocation(program,"uDay"),day);
        glUniform1f(glGetUniformLocation(program,"uCaustics"),scene.caustics?1.0f:0.0f);
        glUniform1f(glGetUniformLocation(program,"uLightPower"),scene.lightPower);
        for(const auto& obj:scene.objects) draw(obj.geometry,obj.model,obj.color,obj.glow,1,obj.plant,obj.floor);
        for(const Fish& f:scene.fish) {
            glm::mat4 body=glm::translate(glm::mat4(1),f.position);
            body=glm::rotate(body,f.heading,glm::vec3(0,1,0));
            body=glm::rotate(body,0.035f*std::sin(scene.time*5+f.phase),glm::vec3(0,0,1));
            body=glm::scale(body,glm::vec3(f.size));
            glm::mat4 torso=glm::scale(body,glm::vec3(1.05f,0.47f,0.33f));
            draw(0,torso,f.color,0.06f);
            glm::mat4 stripe=glm::translate(body,glm::vec3(0,0.10f,0));
            stripe=glm::scale(stripe,glm::vec3(0.87f,0.14f,0.347f));
            draw(0,stripe,f.color*0.57f,0.08f);
            glm::mat4 tail=glm::translate(body,glm::vec3(-1.03f,0,0));
            tail=glm::rotate(tail,0.20f*std::sin(scene.time*10+f.phase),glm::vec3(0,1,0));
            tail=glm::scale(tail,glm::vec3(0.9f,0.68f,1));
            draw(2,tail,f.color*0.84f,0.1f);
            glm::mat4 top=glm::translate(body,glm::vec3(0,0.40f,0));
            top=glm::rotate(top,PI*0.4f,glm::vec3(0,0,1));
            top=glm::scale(top,glm::vec3(0.54f,0.44f,0.8f));
            draw(2,top,f.color*0.82f,0.08f);
            for(int side : {-1,1}) {
                glm::mat4 fin=glm::translate(body,glm::vec3(-0.1f,-0.11f,side*0.29f));
                fin=glm::rotate(fin,side*0.36f,glm::vec3(0,1,0));
                fin=glm::scale(fin,glm::vec3(0.46f,0.4f,0.75f));
                draw(2,fin,f.color*0.87f);
                glm::mat4 eyeBase=glm::translate(body,glm::vec3(0.56f,0.13f,side*0.29f));
                draw(0,glm::scale(eyeBase,glm::vec3(0.12f)),glm::vec3(0.96f,0.98f,0.93f),0.21f);
                glm::mat4 pupil=glm::translate(body,glm::vec3(0.595f,0.14f,side*0.38f));
                draw(0,glm::scale(pupil,glm::vec3(0.061f)),glm::vec3(0.015f,0.025f,0.05f));
            }
        }
        if(scene.jellyEnabled) for(const auto& j:scene.jellyfish) {
            glm::vec3 pos=j.origin+glm::vec3(0.35f*std::sin(scene.time*0.28f+j.phase),0.48f*std::sin(scene.time*0.79f+j.phase),0.25f*std::cos(scene.time*0.29f+j.phase));
            float pulse=1.0f+0.09f*std::sin(scene.time*2.3f+j.phase);
            draw(0,model(pos,{0.66f*j.size*pulse,0.28f*j.size/pulse,0.66f*j.size*pulse}),j.color,0.45f,0.84f);
            draw(0,model(pos+glm::vec3(0,-0.11f*j.size,0),glm::vec3(0.37f,0.11f,0.37f)*j.size),j.color*0.65f,0.5f);
            for(int k=0;k<6;++k) {
                float phase=float(k)*2*PI/6.0f;
                glm::vec3 offset=glm::vec3(0.24f*std::cos(phase),-0.14f,0.24f*std::sin(phase))*j.size;
                glm::mat4 tentacle=glm::translate(glm::mat4(1),pos+offset);
                tentacle=glm::rotate(tentacle,PI+0.15f*std::sin(scene.time*1.3f+phase+j.phase),glm::vec3(0,0,1));
                tentacle=glm::scale(tentacle,glm::vec3(0.026f,0.82f*j.size,0.026f));
                draw(1,tentacle,j.color,0.28f);
            }
        }
        for(const auto& pellet:scene.food) if(pellet.alive)
            draw(0,model(pellet.position,glm::vec3(0.067f)),glm::vec3(0.99f,0.73f,0.25f),0.4f);
        if(scene.bubblesEnabled) {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
            glDepthMask(GL_FALSE);
            for(const auto& b:scene.bubbles) {
                float y=-2.0f+std::fmod(b.offset+scene.time*b.speed,11.0f);
                glm::vec3 pos=b.origin+glm::vec3(std::sin(scene.time*1.2f+b.offset)*0.23f,y+2,0.18f*std::cos(scene.time*0.8f+b.offset));
                draw(0,model(pos,glm::vec3(b.radius)),glm::vec3(0.46f,0.88f,0.97f),0.45f,0.42f);
            }
            glDepthMask(GL_TRUE);
        }
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        glDepthMask(GL_FALSE);
        if(scene.rays) for(int k=0;k<9;++k) {
            float x=-10.7f+float(k)*2.6f;
            glm::mat4 beam=glm::translate(glm::mat4(1),glm::vec3(x+0.28f*std::sin(scene.time*0.19f+k),0,-1.2f+float(k%3)*2.4f));
            beam=glm::rotate(beam,-0.32f+0.07f*k,glm::vec3(0,1,0));
            draw(6,beam,glm::vec3(0.30f,0.89f,0.98f),0,0.12f*scene.day);
        }
        if(scene.surface) {
            draw(5,glm::mat4(1),glm::vec3(0.10f,0.75f,0.88f),0.0f,0.25f);
        }
        glDepthMask(GL_TRUE);
        if(!photoMode) drawHud();
    }
    void drawHud() {
        float w=static_cast<float>(width),h=static_cast<float>(height);
        float scale=std::max(0.7f,std::min(w/1280.0f,h/720.0f));
        hud.rect(22*scale,18*scale,454*scale,89*scale,{0.006f,0.035f,0.09f,0.81f});
        hud.rect(22*scale,18*scale,4*scale,89*scale,{0.24f,0.9f,0.85f,0.98f});
        hud.text(40*scale,35*scale,"3D AQUARIUM EXPLORER",2.6f*scale,{0.82f,0.99f,0.96f,1});
        hud.text(40*scale,78*scale,"LIVING REEF / REAL TIME SIMULATION",1.3f*scale,{0.40f,0.86f,0.87f,1});
        hud.rect(w-284*scale,18*scale,262*scale,112*scale,{0.006f,0.035f,0.09f,0.81f});
        hud.text(w-263*scale,32*scale,scene.autoCycle?"DYNAMIC LIGHTING":(scene.day>0.5f?"DAY MODE":"NIGHT MODE"),2.0f*scale,{0.84f,0.98f,1,1});
        std::ostringstream info;
        info<<"FISH "<<scene.fish.size()<<"   FPS ";
        if(fps<0.5f) info<<"--"; else info<<static_cast<int>(fps);
        hud.text(w-263*scale,69*scale,info.str(),1.45f*scale,{0.41f,0.86f,0.83f,1});
        std::ostringstream state;
        state<<"SCHOOL "<<(scene.schooling?"ON":"OFF")<<"   SPEED "<<int(scene.speedScale*100)<<"%";
        hud.text(w-263*scale,99*scale,state.str(),1.27f*scale,{0.67f,0.89f,0.91f,1});
        if(help) {
            hud.rect(22*scale,h-166*scale,751*scale,144*scale,{0.006f,0.035f,0.09f,0.82f});
            const std::array<std::string,5> entries={
                "DRAG / ARROWS CAMERA   W S ZOOM",
                "1 DAY  2 NIGHT  T LIGHT CYCLE  F FEED",
                "+ - FISH COUNT    [ ] SIMULATION SPEED",
                "M SCHOOL  C CAUSTICS  L RAYS  U WAVES",
                "J JELLYFISH B BUBBLES SPACE PAUSE R RESET H HELP TAB PANEL P PHOTO"
            };
            for(int i=0;i<5;++i) hud.text(38*scale,h-(149-i*27)*scale,entries[i],1.45f*scale,i==0?glm::vec4(0.89f,0.98f,1,1):glm::vec4(0.55f,0.9f,0.93f,1));
        } else {
            hud.rect(22*scale,h-42*scale,280*scale,23*scale,{0.006f,0.035f,0.09f,0.7f});
            hud.text(36*scale,h-36*scale,"PRESS H FOR CONTROLS",1.3f*scale,{0.62f,0.89f,0.91f,1});
        }
        if(settingsPanel) {
            float px=w-330*scale,py=h-385*scale;
            hud.rect(px,py,308*scale,218*scale,{0.007f,0.046f,0.083f,0.86f});
            hud.rect(px,py,4*scale,218*scale,{0.27f,0.90f,0.87f,1});
            hud.text(px+21*scale,py+20*scale,"REEF LAB SETTINGS",1.9f*scale,{0.81f,0.99f,0.96f,1});
            std::array<std::string,6> fields={
                std::string("FISH ")+std::to_string(scene.fish.size())+" / 64",
                std::string("SCHOOLING ")+(scene.schooling?"ON":"OFF"),
                std::string("WAVES ")+(scene.surface?"ON":"OFF"),
                std::string("LIGHT RAYS ")+(scene.rays?"ON":"OFF"),
                std::string("CAUSTICS ")+(scene.caustics?"ON":"OFF"),
                std::string("JELLYFISH ")+(scene.jellyEnabled?"ON":"OFF")
            };
            for(int i=0;i<6;++i) hud.text(px+21*scale,py+(59+i*24)*scale,fields[i],1.45f*scale,{0.57f,0.91f,0.93f,1});
        }
        if(scene.paused) {
            hud.rect(w*0.5f-125*scale,h*0.43f,250*scale,64*scale,{0.005f,0.04f,0.08f,0.79f});
            hud.text(w*0.5f-85*scale,h*0.43f+20*scale,"PAUSED",3.2f*scale,{1,1,1,1});
        }
        if(scene.foodTimer>0.0f) {
            hud.rect(w-284*scale,h-182*scale,262*scale,35*scale,{0.13f,0.26f,0.28f,0.82f});
            std::ostringstream eating;
            eating<<"FEEDING  EATEN "<<scene.foodEaten;
            hud.text(w-264*scale,h-170*scale,eating.str(),1.35f*scale,{1,0.88f,0.53f,1});
        }
        hud.render(width,height);
    }
    void destroy() {
        for(auto& mesh:meshes) mesh.destroy();
        hud.destroy();
        if(program) glDeleteProgram(program);
    }
};

void onKey(GLFWwindow* w,int key,int,int action,int) {
    if(action!=GLFW_PRESS) return;
    App& a=*static_cast<App*>(glfwGetWindowUserPointer(w));
    if(key==GLFW_KEY_ESCAPE) glfwSetWindowShouldClose(w,1);
    if(key==GLFW_KEY_1) {a.scene.day=1;a.scene.autoCycle=false;}
    if(key==GLFW_KEY_2) {a.scene.day=0;a.scene.autoCycle=false;}
    if(key==GLFW_KEY_T) a.scene.autoCycle=!a.scene.autoCycle;
    if(key==GLFW_KEY_M) a.scene.schooling=!a.scene.schooling;
    if(key==GLFW_KEY_C) a.scene.caustics=!a.scene.caustics;
    if(key==GLFW_KEY_L) a.scene.rays=!a.scene.rays;
    if(key==GLFW_KEY_U) a.scene.surface=!a.scene.surface;
    if(key==GLFW_KEY_J) a.scene.jellyEnabled=!a.scene.jellyEnabled;
    if(key==GLFW_KEY_EQUAL || key==GLFW_KEY_KP_ADD) a.scene.setFishCount(static_cast<int>(a.scene.fish.size())+4);
    if(key==GLFW_KEY_MINUS || key==GLFW_KEY_KP_SUBTRACT) a.scene.setFishCount(static_cast<int>(a.scene.fish.size())-4);
    if(key==GLFW_KEY_LEFT_BRACKET) a.scene.speedScale=std::max(0.5f,a.scene.speedScale-0.25f);
    if(key==GLFW_KEY_RIGHT_BRACKET) a.scene.speedScale=std::min(2.0f,a.scene.speedScale+0.25f);
    if(key==GLFW_KEY_SPACE) a.scene.paused=!a.scene.paused;
    if(key==GLFW_KEY_F) a.scene.feed();
    if(key==GLFW_KEY_B) a.scene.bubblesEnabled=!a.scene.bubblesEnabled;
    if(key==GLFW_KEY_H) a.help=!a.help;
    if(key==GLFW_KEY_TAB) a.settingsPanel=!a.settingsPanel;
    if(key==GLFW_KEY_P) a.photoMode=!a.photoMode;
    if(key==GLFW_KEY_COMMA) a.scene.lightPower=std::max(0.6f,a.scene.lightPower-0.15f);
    if(key==GLFW_KEY_PERIOD) a.scene.lightPower=std::min(1.6f,a.scene.lightPower+0.15f);
    if(key==GLFW_KEY_R) {a.scene.initialize();a.camera=Camera();}
}

void onCursor(GLFWwindow* w,double x,double y) {
    App& a=*static_cast<App*>(glfwGetWindowUserPointer(w));
    if(a.dragging) {
        a.camera.yaw+=static_cast<float>((x-a.mouseX)*0.006);
        a.camera.pitch+=static_cast<float>((y-a.mouseY)*0.004);
        a.camera.clamp();
    }
    a.mouseX=x;a.mouseY=y;
}

void onMouse(GLFWwindow* w,int button,int action,int) {
    App& a=*static_cast<App*>(glfwGetWindowUserPointer(w));
    if(button==GLFW_MOUSE_BUTTON_LEFT) a.dragging=action==GLFW_PRESS;
}

void onScroll(GLFWwindow* w,double,double y) {
    App& a=*static_cast<App*>(glfwGetWindowUserPointer(w));
    a.camera.radius-=static_cast<float>(y*1.4);
    a.camera.clamp();
}

bool savePPM(const std::string& filename,int width,int height) {
    std::vector<unsigned char> pixels(static_cast<size_t>(width)*height*3);
    glPixelStorei(GL_PACK_ALIGNMENT,1);
    glReadBuffer(GL_BACK);
    glReadPixels(0,0,width,height,GL_RGB,GL_UNSIGNED_BYTE,pixels.data());
    std::ofstream out(filename,std::ios::binary);
    if(!out) return false;
    out<<"P6\n"<<width<<" "<<height<<"\n255\n";
    for(int y=height-1;y>=0;--y)
        out.write(reinterpret_cast<const char*>(pixels.data()+static_cast<size_t>(y)*width*3),static_cast<std::streamsize>(width*3));
    return static_cast<bool>(out);
}

int selfTest() {
    Scene a;
    a.initialize();
    if(a.fish.size()!=24||a.jellyfish.size()!=8||a.bubbles.size()!=105||a.objects.size()<100) return 1;
    if(sphere(18,12).indices.size()!=18*12*6) return 2;
    if(seabed().indices.size()!=50*50*6||waterSurface().indices.size()!=56*56*6||lightBeam().indices.size()!=6) return 3;
    a.feed();
    if(a.food.size()!=38||a.feedCount!=1) return 4;
    glm::vec3 first=a.fish[0].position;
    for(int i=0;i<120;++i) a.update(1.0f/60.0f);
    if(glm::length(a.fish[0].position-first)<0.01f) return 5;
    for(int i=0;i<400;++i) a.update(1.0f/60.0f);
    for(const auto& f:a.fish) if(!std::isfinite(f.position.x)||!std::isfinite(f.position.y)||!std::isfinite(f.position.z)||glm::length(glm::vec2(f.position.x,f.position.z))>13.21f) return 6;
    a.setFishCount(40);
    if(a.fish.size()!=40) return 7;
    a.setFishCount(500);
    if(a.fish.size()!=64) return 8;
    a.setFishCount(-20);
    if(a.fish.size()!=8) return 9;
    a.autoCycle=true;
    a.update(0.1f);
    if(a.day<0.0f||a.day>1.0f) return 10;
    Scene feeding;
    feeding.initialize();
    feeding.feed();
    for(int k=0;k<520;++k) feeding.update(1.0f/60.0f);
    if(feeding.foodEaten<1) return 12;
    Scene solo;
    Scene groups;
    solo.initialize();
    groups.initialize();
    solo.schooling=false;
    for(int k=0;k<180;++k) {
        solo.update(1.0f/60.0f);
        groups.update(1.0f/60.0f);
    }
    if(glm::distance(solo.fish[2].position,groups.fish[2].position)<0.01f) return 13;
    a.paused=true;
    float hold=a.time;
    a.update(0.1f);
    if(a.time!=hold) return 11;
    std::cout<<"PASS: geometry, reef, separation, schooling, bounds, fish limits, food consumption, lighting, pause\n";
    std::cout<<"Food particles consumed during 8.7 s simulation: "<<feeding.foodEaten<<" / "<<feeding.food.size()<<"\n";
    return 0;
}

void glfwError(int code,const char* text) { std::cerr<<"GLFW "<<code<<": "<<text<<"\n"; }

int main(int argc,char** argv) {
    bool headless=false, night=false, feedDemo=false, hideHelp=false, photo=false;
    std::string capture;
    int limit=0;
    int fishOverride=0;
    for(int i=1;i<argc;++i) {
        std::string a=argv[i];
        if(a=="--self-test") return selfTest();
        if(a=="--headless") headless=true;
        if(a=="--night") night=true;
        if(a=="--feed-demo") feedDemo=true;
        if(a=="--hide-help") hideHelp=true;
        if(a=="--fish" && i+1<argc) fishOverride=std::atoi(argv[++i]);
        if(a=="--photo") photo=true;
        if(a=="--capture" && i+1<argc) capture=argv[++i];
        if(a=="--frames" && i+1<argc) limit=std::max(1,std::atoi(argv[++i]));
    }
    glfwSetErrorCallback(glfwError);
    try {
        std::filesystem::path executable=std::filesystem::absolute(argv[0]).parent_path();
        if(std::filesystem::exists(executable/"shaders")) std::filesystem::current_path(executable);
    } catch(const std::exception&) {}
    if(headless) glfwInitHint(GLFW_PLATFORM,GLFW_PLATFORM_NULL);
    if(!glfwInit()) {
        std::cerr<<"GLFW initialization failed\n";
        return 1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT,GL_TRUE);
#endif
    glfwWindowHint(GLFW_SAMPLES,headless?0:4);
    if(headless) {
        glfwWindowHint(GLFW_CONTEXT_CREATION_API,GLFW_EGL_CONTEXT_API);
        glfwWindowHint(GLFW_VISIBLE,GLFW_FALSE);
        glfwWindowHint(GLFW_DEPTH_BITS,16);
        glfwWindowHint(GLFW_STENCIL_BITS,0);
        glfwWindowHint(GLFW_ALPHA_BITS,0);
    }
    App app;
    app.window=glfwCreateWindow(1280,720,"3D Aquarium Explorer",nullptr,nullptr);
    if(!app.window) {
        std::cerr<<"OpenGL 3.3 window creation failed\n";
        glfwTerminate();
        return 2;
    }
    glfwMakeContextCurrent(app.window);
    glfwSwapInterval(headless?0:1);
    if(!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) {
        std::cerr<<"OpenGL function loading failed\n";
        glfwDestroyWindow(app.window);
        glfwTerminate();
        return 3;
    }
    glfwSetWindowUserPointer(app.window,&app);
    glfwSetKeyCallback(app.window,onKey);
    glfwSetCursorPosCallback(app.window,onCursor);
    glfwSetMouseButtonCallback(app.window,onMouse);
    glfwSetScrollCallback(app.window,onScroll);
    try {
        app.initialize();
        if(fishOverride) app.scene.setFishCount(fishOverride);
        if(night) app.scene.day=0;
        if(hideHelp) app.help=false;
        if(photo) app.photoMode=true;
        if(feedDemo) {
            app.scene.feed();
            for(int j=0;j<70;++j) app.scene.update(0.05f);
        }
        app.lastTime=glfwGetTime();
        app.lastFps=app.lastTime;
        int count=0;
        while(!glfwWindowShouldClose(app.window)) {
            double now=glfwGetTime();
            float dt=static_cast<float>(now-app.lastTime);
            app.lastTime=now;
            app.controls(std::min(0.05f,dt));
            app.scene.update(dt);
            app.render();
            if(!capture.empty() && limit>0 && count+1==limit) {
                glFinish();
                if(!savePPM(capture,app.width,app.height)) std::cerr<<"Failed to save capture\n";
            }
            glfwSwapBuffers(app.window);
            glfwPollEvents();
            ++count;
            app.frames++;
            if(now-app.lastFps>=1.0) {
                app.fps=static_cast<float>(app.frames/(now-app.lastFps));
                app.lastFps=now;
                app.frames=0;
            }
            if(limit>0 && count>=limit) break;
        }
        app.destroy();
    } catch(const std::exception& e) {
        std::cerr<<e.what()<<"\n";
        glfwDestroyWindow(app.window);
        glfwTerminate();
        return 4;
    }
    glfwDestroyWindow(app.window);
    glfwTerminate();
    return 0;
}
