#version 330 core
in vec3 vWorld;
in vec3 vNormal;
in vec3 vEye;
out vec4 FragColor;
uniform vec3 uColor;
uniform vec3 uCamera;
uniform float uTime;
uniform float uDay;
uniform float uAlpha;
uniform float uGlow;
uniform float uFloor;
uniform float uSurface;
uniform float uBeam;
uniform float uCaustics;
uniform float uLightPower;
void main() {
    if(uBeam>0.5) {
        float fade=pow(clamp((vWorld.y+2.1)/10.5,0.0,1.0),0.7);
        float pulse=0.7+0.3*sin(vWorld.y*0.5+vWorld.x*0.7+uTime*0.8);
        FragColor=vec4(uColor*(0.65+0.35*uDay),uAlpha*fade*pulse);
        return;
    }
    if(uSurface>0.5) {
        float a=sin(vWorld.x*1.4+uTime*1.5)*cos(vWorld.z*1.2-uTime*0.7);
        float b=sin(vWorld.z*2.2+vWorld.x*0.8-uTime*1.1);
        float shine=pow(max(0.0,a*b),6.0);
        FragColor=vec4(vec3(0.08,0.43,0.58)+vec3(0.2,0.55,0.56)*(0.3+0.7*shine),uAlpha*(0.5+0.32*shine)*uDay);
        return;
    }
    vec3 N=normalize(vNormal);
    vec3 L=normalize(vec3(-0.34,0.9,0.42));
    vec3 V=normalize(uCamera-vWorld);
    float diffuse=max(dot(N,L),0.0);
    float spec=pow(max(dot(reflect(-L,N),V),0.0),28.0);
    float caustic=0.0;
    if(uFloor>0.5 && uCaustics>0.5) {
        float a=sin(vWorld.x*1.25+uTime*1.3+sin(vWorld.z*1.2+uTime));
        float b=sin(vWorld.z*1.6-uTime*1.1+sin(vWorld.x*0.8));
        caustic=pow(max(0.0,a*b),7.0)*0.53;
    }
    float ambient=mix(0.28,0.46,uDay);
    vec3 lit=uColor*(ambient+diffuse*mix(0.24,0.73,uDay)*uLightPower+caustic*uDay*uLightPower);
    lit+=vec3(0.7,0.95,1.0)*spec*0.24*uDay;
    lit+=uColor*uGlow;
    lit+=vec3(0.015,0.055,0.085)*(1.0-uDay);
    float dist=length(vEye);
    float fog=1.0-exp(-dist*dist*0.00115);
    vec3 fogColor=mix(vec3(0.006,0.025,0.067),vec3(0.023,0.14,0.23),uDay);
    lit=mix(lit,fogColor,clamp(fog,0.0,0.82));
    float depthDim=clamp(1.0-vWorld.y*0.011,0.7,1.2);
    FragColor=vec4(lit*depthDim,uAlpha);
}
