#version 330 core
layout(location=0) in vec2 aPosition;
layout(location=1) in vec4 aColor;
out vec4 vColor;
uniform vec2 uResolution;
void main() {
    vec2 xy=(aPosition/uResolution)*2.0-1.0;
    gl_Position=vec4(xy.x,-xy.y,0.0,1.0);
    vColor=aColor;
}
