#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNormal;
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;
uniform float uTime;
uniform float uPlant;
uniform float uSurface;
out vec3 vWorld;
out vec3 vNormal;
out vec3 vEye;
void main() {
    vec3 p=aPos;
    if(uPlant>0.5) {
        float bend=pow(max(0.0,p.y),1.45)*0.07;
        p.x+=bend*sin(uTime*1.8+p.y*0.8+uModel[3].x);
        p.z+=bend*0.52*cos(uTime*1.2+p.y*0.57+uModel[3].z);
    }
    if(uSurface>0.5) {
        p.y+=0.19*sin(p.x*0.92+uTime*0.78)*cos(p.z*0.66-uTime*0.64);
        p.y+=0.08*sin(p.x*1.54+p.z*0.6+uTime*1.1);
    }
    vec4 world=uModel*vec4(p,1.0);
    vWorld=world.xyz;
    vNormal=normalize(mat3(transpose(inverse(uModel)))*aNormal);
    vec4 eye=uView*world;
    vEye=eye.xyz;
    gl_Position=uProjection*eye;
}
